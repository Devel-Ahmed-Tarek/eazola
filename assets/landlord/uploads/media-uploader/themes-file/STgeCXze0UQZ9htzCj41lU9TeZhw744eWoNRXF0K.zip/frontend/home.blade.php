<section id="courses" class="course-grid">
  <div class="course-card">
    <h3>كورس التسويق الرقمي</h3>
    <p>تعلم أساسيات التسويق من الصفر</p>
    <div class="price">499 جنيه</div>
    <a href="#" class="btn-course">اشترك</a>
  </div>

  <div class="course-card">
    <h3>كورس تصميم UI/UX</h3>
    <p>من الفكرة إلى التصميم الاحترافي</p>
    <div class="price">699 جنيه</div>
    <a href="#" class="btn-course">اشترك</a>
  </div>
</section>
