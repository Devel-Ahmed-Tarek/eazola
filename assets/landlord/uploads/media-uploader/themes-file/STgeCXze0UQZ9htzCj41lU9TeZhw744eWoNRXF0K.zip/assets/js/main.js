document.addEventListener("DOMContentLoaded", () => {
  console.log("Eazola Courses Theme Loaded Successfully");
});
