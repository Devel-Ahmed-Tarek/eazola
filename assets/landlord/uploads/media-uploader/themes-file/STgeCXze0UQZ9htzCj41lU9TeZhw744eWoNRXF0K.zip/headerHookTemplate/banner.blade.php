<div class="course-hero">
  <h1>تعلم مهارات المستقبل</h1>
  <p>كورسات احترافية أونلاين بشهادات معتمدة</p>
  <a href="#courses" class="btn-course">ابدأ الآن</a>
</div>
