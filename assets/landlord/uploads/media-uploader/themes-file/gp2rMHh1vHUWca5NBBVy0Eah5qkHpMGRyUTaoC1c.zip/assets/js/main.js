document.addEventListener("DOMContentLoaded", () => {
  console.log("Eazola SAFE theme loaded");
});
